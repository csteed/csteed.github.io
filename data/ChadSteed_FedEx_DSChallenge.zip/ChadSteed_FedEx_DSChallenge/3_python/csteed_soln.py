import sys
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import VotingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

# Function to compute standard metrics for created models
def computeEvalMetrics(rg, X_test, y_test, y_predicted):
  metrics = {}
  metrics['mse'] = mean_squared_error(y_predicted, y_test)
  metrics['rmse'] = np.sqrt(metrics['mse'])
  metrics['score'] = rg.score(X_test, y_test)
  return metrics

def createAndEvalModels(df):
  # create random test and train subsets using 20% of the original data and a random state of 1 for reproducibility
  y = df['y']
  X = df[list(df.columns)[1:]]
  X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 1)

  # Linear Regression
  reg_lin = LinearRegression()
  reg_lin.fit(X_train, y_train)
  y_predicted = reg_lin.predict(X_test)
  reg_lin_metrics = computeEvalMetrics(reg_lin, X_test, y_test, y_predicted)
  print('Linear Regression:')
  print(' ', reg_lin_metrics)

  # Gradient Boosting Regressor
  reg_gb = GradientBoostingRegressor(random_state = 1)
  reg_gb.fit(X_train, y_train)
  y_predicted = reg_gb.predict(X_test)
  reg_gb_metrics = computeEvalMetrics(reg_gb, X_test, y_test, y_predicted)
  print('Gradient Boosting Regressor:')
  print(' ', reg_gb_metrics)

  # Random Forest Regressor
  reg_rf = RandomForestRegressor(random_state = 1)
  reg_rf.fit(X_train, y_train)
  y_predicted = reg_rf.predict(X_test)
  reg_rf_metrics = computeEvalMetrics(reg_rf, X_test, y_test, y_predicted)
  print('Random Forest Regressor:')
  print(' ', reg_rf_metrics)

  # Voting Regressor
  reg_vote = VotingRegressor([('gb', reg_gb), ('rf', reg_rf), ('lr', reg_lin)])
  reg_vote.fit(X_train, y_train)
  y_predicted = reg_vote.predict(X_test)
  reg_vote_metrics = computeEvalMetrics(reg_vote, X_test, y_test, y_predicted)
  print('Voting Regressor (gb - rf - lin):')
  print(reg_vote_metrics)

  return {
    'linear': reg_lin_metrics,
    'gradient_boost': reg_gb_metrics,
    'random_forest': reg_rf_metrics,
    'voting_regressor': reg_vote_metrics
  }

print('hello')
print(sys.argv)
if len(sys.argv) != 2:
  print('Usage: python3 csteed_soln.py <data_filename>')
  exit

data = pd.read_csv(sys.argv[1])
print('Original data file information:')
print(data.info())

print('Original data file description:')
print(data.describe())

# Prediction models #1
# Dropping null values and comparing four models
print('\Experiment 1 (dropping null values with all features):')
data_droppedna = data.dropna()
# print(data_droppedna.info())
results = createAndEvalModels(data_droppedna)

# Prediction models #2
# Replacing null values with column mean and comparing four models
print('\nExperiment 2 (replace means with column mean):')
data_meanreplace = data.fillna(data.mean())
results = createAndEvalModels(data_meanreplace)

# Prediction models #3
# Replacing null values with column mean and comparing four models
print('\nExperiment 3 (drop nulls and use only columns x10, x11, x12, x15, and x16):')
data_subset1 = data[['y','x10','x11','x12','x15','x16']].dropna()
results = createAndEvalModels(data_subset1)

# Prediction models #4
# Replacing null values with column mean and comparing four models
print('\nExperiment 4 (drop nulls and use only columns x10, x12, x15, and x16):')
data_subset2 = data[['y','x10','x12','x15','x16']].dropna()
results = createAndEvalModels(data_subset2)
