# FedEx Data Science Coding Challenge Solution
# by Chad A. Steed
# Oct. 24, 2020

The best place to begin is my report, which is stored in the report folder. This include all the results and instrutions for running the code.


** Description of Directories **

- 0_report/ - Contains the report on my work and instructions for using the notebooks, python code, and related web apps. This folder also has a Excel files with the learning model results and the original figures used in the report.

- 1_notebook/ - Contains the JupyterLab notebook files used for exploring the data and creating the learning models. This folder also contains a directory called plots where the predicted vs. test plots for each model I created are stored.

- 2_crossvis-web/ - Contains source code for the CrossVis web applications (beta release) that I use in some of the analysis. Instructions for running the web app are provided in my report.

- 3_python/ - This contains a lighter version of the code in my notebook files, focusing just on building the models and evaluating the results. The notebook files are preferred, but in case there is trouble with those, this python code is provided.

- data/ - Contains the original data set provided by FedEx.
